package dev.dgdigital.frequencyfield.nativeapp

import android.app.Activity
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import java.util.ArrayDeque
import kotlin.math.*

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var magneticSensor: Sensor? = null
    private lateinit var fieldView: FieldView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(3, 4, 10)
        window.navigationBarColor = Color.rgb(3, 4, 10)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(3, 4, 10)))
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        magneticSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        fieldView = FieldView(magneticSensor?.name ?: "No magnetic sensor")
        setContentView(fieldView)

        if (magneticSensor == null) {
            fieldView.setFatal("This phone does not expose TYPE_MAGNETIC_FIELD.")
        }
    }

    override fun onResume() {
        super.onResume()
        magneticSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST, 0)
        }
        fieldView.running = magneticSensor != null
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        fieldView.running = false
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_MAGNETIC_FIELD || event.values.size < 3) return
        fieldView.acceptSample(
            event.timestamp / 1_000_000.0,
            event.values[0].toDouble(),
            event.values[1].toDouble(),
            event.values[2].toDouble()
        )
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        fieldView.sensorAccuracy = accuracy
    }

    private inner class FieldView(private val sensorName: String) : View(this@MainActivity) {
        private data class Sample(val t: Double, val x: Double, val y: Double, val z: Double, val m: Double)
        private data class Dot(var x: Float, var y: Float, var vx: Float, var vy: Float, val size: Float, val seed: Float)

        private val bg = Color.rgb(3, 4, 10)
        private val white = Color.rgb(245, 247, 255)
        private val muted = Color.rgb(124, 132, 156)
        private val cyan = Color.rgb(115, 214, 255)
        private val violet = Color.rgb(178, 138, 255)
        private val emerald = Color.rgb(103, 232, 177)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val history = ArrayDeque<Sample>(600)
        private val particles = ArrayList<Dot>(130)
        private var baseline = Double.NaN
        private var autoBaselineReady = false
        private var lastUiAnalysis = 0L
        private var lastFrameNs = 0L
        private var mode = 0
        private var fatal: String? = null

        @Volatile var running = false
        @Volatile var sensorAccuracy = SensorManager.SENSOR_STATUS_UNRELIABLE
        @Volatile private var x = 0.0
        @Volatile private var y = 0.0
        @Volatile private var z = 0.0
        @Volatile private var magnitude = 0.0
        @Volatile private var delta = 0.0
        @Volatile private var sampleRate = 0.0
        @Volatile private var bandwidth = 0.0
        @Volatile private var oscillation = Double.NaN
        @Volatile private var confidence = 0.0

        init {
            isFocusable = true
            repeat(130) {
                particles += Dot(
                    x = Math.random().toFloat(),
                    y = Math.random().toFloat(),
                    vx = 0f,
                    vy = 0f,
                    size = (0.8 + Math.random() * 2.3).toFloat(),
                    seed = (Math.random() * Math.PI * 2).toFloat()
                )
            }
        }

        fun setFatal(message: String) {
            fatal = message
            invalidate()
        }

        fun acceptSample(t: Double, sx: Double, sy: Double, sz: Double) {
            val m = sqrt(sx * sx + sy * sy + sz * sz)
            synchronized(history) {
                if (history.size >= 600) history.removeFirst()
                history.addLast(Sample(t, sx, sy, sz, m))
                if (!autoBaselineReady && history.size >= 30) {
                    baseline = history.takeLastCompat(30).map { it.m }.average()
                    autoBaselineReady = true
                }
            }
            x = sx; y = sy; z = sz; magnitude = m
            if (!baseline.isNaN()) delta = m - baseline

            val now = SystemClock.uptimeMillis()
            if (now - lastUiAnalysis >= 140) {
                analyze()
                lastUiAnalysis = now
            }
            postInvalidateOnAnimation()
        }

        private fun analyze() {
            val list = synchronized(history) { history.toList() }
            if (list.size < 3) return
            val window = list.takeLast(90)
            var dt = 0.0
            var count = 0
            for (i in 1 until window.size) {
                val d = window[i].t - window[i - 1].t
                if (d > 0.0 && d < 1000.0) { dt += d; count++ }
            }
            if (count > 0 && dt > 0.0) {
                sampleRate = 1000.0 * count / dt
                bandwidth = sampleRate / 2.0
            }

            val n = min(180, list.size)
            if (n < 48 || sampleRate < 2.0 || baseline.isNaN()) {
                oscillation = Double.NaN
                confidence = 0.0
                return
            }
            val series = list.takeLast(n).map { it.m - baseline }
            val mean = series.average()
            val centered = series.map { it - mean }
            val variance = centered.sumOf { it * it } / n
            if (variance < 1e-5) {
                oscillation = Double.NaN
                confidence = 0.0
                return
            }

            val minF = 0.4
            val maxF = min(20.0, sampleRate / 2.0 - 0.5)
            if (maxF <= minF) return
            val step = max(0.12, sampleRate / n)
            var f = minF
            var bestF = Double.NaN
            var bestPower = 0.0
            var sumPower = 0.0
            while (f <= maxF) {
                var re = 0.0
                var im = 0.0
                for (i in centered.indices) {
                    val phase = 2.0 * Math.PI * f * i / sampleRate
                    re += centered[i] * cos(phase)
                    im -= centered[i] * sin(phase)
                }
                val power = re * re + im * im
                sumPower += power
                if (power > bestPower) { bestPower = power; bestF = f }
                f += step
            }
            confidence = (bestPower / (sumPower + 1e-9) * 10.0).coerceIn(0.0, 1.0)
            oscillation = if (confidence >= 0.18) bestF else Double.NaN
        }

        private fun calibrate() {
            val list = synchronized(history) { history.toList() }
            if (list.size < 12) return
            baseline = list.takeLast(min(80, list.size)).map { it.m }.average()
            autoBaselineReady = true
            delta = magnitude - baseline
            performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM)
            invalidate()
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_UP) return true
            val w = width.toFloat()
            val h = height.toFloat()
            val tabTop = dp(72f)
            val tabBottom = dp(124f)
            if (event.y in tabTop..tabBottom) {
                mode = when {
                    event.x < w / 3f -> 0
                    event.x < w * 2f / 3f -> 1
                    else -> 2
                }
                performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                invalidate()
                return true
            }
            if (event.y > h - dp(84f)) {
                calibrate()
                return true
            }
            return true
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            c.drawColor(bg)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return

            drawGrid(c, w, h)
            drawReactiveField(c, w, h)
            drawHeader(c, w)

            fatal?.let {
                paint.color = Color.rgb(255, 145, 157)
                paint.textSize = sp(18f)
                paint.typeface = Typeface.DEFAULT_BOLD
                drawCentered(c, it, h * 0.5f, paint)
                return
            }

            drawTabs(c, w)
            drawHero(c, w)
            drawTrace(c, w, h)
            drawMetrics(c, w, h)
            drawBottom(c, w, h)
            postInvalidateOnAnimation()
        }

        private fun drawGrid(c: Canvas, w: Float, h: Float) {
            paint.color = Color.argb(15, 255, 255, 255)
            paint.strokeWidth = 1f
            val step = dp(32f)
            var px = 0f
            while (px < w) { c.drawLine(px, 0f, px, h, paint); px += step }
            var py = 0f
            while (py < h) { c.drawLine(0f, py, w, py, paint); py += step }
        }

        private fun drawReactiveField(c: Canvas, w: Float, h: Float) {
            val cx = w * (0.5f + (x / 80.0).coerceIn(-1.0, 1.0).toFloat() * 0.08f)
            val cy = h * (0.34f - (y / 80.0).coerceIn(-1.0, 1.0).toFloat() * 0.04f)
            val energy = (0.09 + min(1.0, abs(delta) / 15.0) * 0.91).toFloat()
            val t = SystemClock.uptimeMillis() / 1000f

            val halo = RadialGradient(cx, cy, w * (0.18f + energy * .16f),
                intArrayOf(Color.argb((55 + energy * 65).toInt(), 122, 123, 255), Color.TRANSPARENT),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
            paint.shader = halo
            c.drawCircle(cx, cy, w * .42f, paint)
            paint.shader = null

            if (mode == 0) {
                for (i in 0 until 7) {
                    val a = t * (.19f + i * .035f) + i * .88f
                    val ox = cos(a) * w * (.08f + i * .012f)
                    val oy = sin(a * 1.17f) * h * (.028f + i * .006f)
                    val r = w * (.055f + i * .018f + energy * .025f)
                    paint.shader = RadialGradient(cx + ox, cy + oy, r,
                        Color.argb((28 + energy * 35).toInt(), 95 + i * 12, 130 + i * 8, 255),
                        Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    c.drawCircle(cx + ox, cy + oy, r, paint)
                }
                paint.shader = null
            }

            val ringCount = if (mode == 1) 8 else 4
            stroke.style = Paint.Style.STROKE
            stroke.strokeWidth = if (mode == 1) dp(1.2f) else dp(.8f)
            for (ring in 0 until ringCount) {
                val path = Path()
                val baseR = w * (.07f + ring * .035f + energy * .015f)
                for (s in 0..180) {
                    val a = s / 180f * (Math.PI * 2).toFloat()
                    val rip = sin(a * (4 + ring) + t * (1.2f + (if (oscillation.isNaN()) 0f else oscillation.toFloat() * .05f))) * (dp(3f) + energy * dp(10f))
                    val micro = if (mode == 1) sin(a * (9 + ring * 2) - t) * (dp(2f) + confidence.toFloat() * dp(8f)) else 0f
                    val r = baseR + rip + micro
                    val px = cx + cos(a) * r
                    val py = cy + sin(a) * r
                    if (s == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                stroke.color = Color.argb(if (mode == 1) 46 else 25, 105 + ring * 10, 170, 255)
                c.drawPath(path, stroke)
            }

            val dt = if (lastFrameNs == 0L) .016f else ((System.nanoTime() - lastFrameNs) / 1_000_000_000.0).toFloat().coerceIn(.005f, .04f)
            lastFrameNs = System.nanoTime()
            val fx = (x / 80.0).coerceIn(-1.0, 1.0).toFloat()
            val fy = (y / 80.0).coerceIn(-1.0, 1.0).toFloat()
            for (p in particles) {
                val swirl = sin(t * .8f + p.seed) * .08f
                p.vx = p.vx * .94f + (fx * .13f + cos(t * .6f + p.seed) * .04f + swirl) * dt
                p.vy = p.vy * .94f + (-fy * .13f + sin(t * .7f + p.seed) * .04f - swirl) * dt
                p.x += p.vx
                p.y += p.vy
                if (p.x < -.05f) p.x = 1.05f
                if (p.x > 1.05f) p.x = -.05f
                if (p.y < -.05f) p.y = 1.05f
                if (p.y > 1.05f) p.y = -.05f
                val pulse = .5f + .5f * sin(t * (1.2f + confidence.toFloat() * 4f) + p.seed)
                paint.color = Color.argb(if (mode == 2) 70 else 34, 160 + (pulse * 45).toInt(), 190, 255)
                c.drawCircle(p.x * w, p.y * h, dp(p.size * (0.7f + energy * 1.2f)), paint)
            }
        }

        private fun drawHeader(c: Canvas, w: Float) {
            paint.shader = null
            paint.color = white
            paint.textSize = sp(13f)
            paint.typeface = Typeface.DEFAULT_BOLD
            c.drawText("FREQUENCY FIELD", dp(20f), dp(30f), paint)
            paint.color = muted
            paint.textSize = sp(9f)
            paint.typeface = Typeface.DEFAULT
            c.drawText("NATIVE MAGNETOMETER • OFFLINE", dp(20f), dp(46f), paint)

            val live = running
            paint.color = if (live) emerald else muted
            c.drawCircle(w - dp(68f), dp(31f), dp(3f), paint)
            paint.textSize = sp(9f)
            c.drawText(if (live) "LIVE" else "IDLE", w - dp(58f), dp(34f), paint)
        }

        private fun drawTabs(c: Canvas, w: Float) {
            val top = dp(72f)
            val bottom = dp(124f)
            paint.color = Color.argb(80, 0, 0, 0)
            roundRect(c, dp(18f), top, w - dp(18f), bottom, dp(18f), paint)
            val labels = arrayOf("Fluid", "Cymatic", "Particles")
            val cell = (w - dp(36f)) / 3f
            for (i in 0..2) {
                if (mode == i) {
                    paint.color = Color.WHITE
                    roundRect(c, dp(22f) + cell * i, top + dp(4f), dp(14f) + cell * (i + 1), bottom - dp(4f), dp(14f), paint)
                }
                paint.color = if (mode == i) Color.BLACK else Color.rgb(145, 145, 160)
                paint.textSize = sp(13f)
                paint.typeface = Typeface.DEFAULT_BOLD
                paint.textAlign = Paint.Align.CENTER
                c.drawText(labels[i], dp(18f) + cell * (i + .5f), top + dp(32f), paint)
            }
            paint.textAlign = Paint.Align.LEFT
        }

        private fun drawHero(c: Canvas, w: Float) {
            paint.color = Color.argb(150, 220, 225, 255)
            paint.textSize = sp(9f)
            paint.letterSpacing = .18f
            paint.textAlign = Paint.Align.CENTER
            c.drawText("LIVE MAGNETIC FIELD", w / 2f, dp(160f), paint)
            paint.letterSpacing = 0f
            paint.color = white
            paint.textSize = sp(48f)
            paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            c.drawText(if (running) "${fmt(magnitude, 2)} µT" else "— µT", w / 2f, dp(212f), paint)
            paint.textSize = sp(11f)
            paint.color = Color.rgb(180, 185, 205)
            val base = if (baseline.isNaN()) "—" else fmt(baseline, 2)
            val osc = if (oscillation.isNaN()) "—" else fmt(oscillation, 2)
            c.drawText("Δ ${fmt(delta, 2)} µT   •   BASE $base µT   •   OSC $osc Hz", w / 2f, dp(238f), paint)
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.DEFAULT
        }

        private fun drawTrace(c: Canvas, w: Float, h: Float) {
            val top = dp(262f)
            val bottom = dp(330f)
            paint.color = Color.argb(70, 0, 0, 0)
            roundRect(c, dp(16f), top, w - dp(16f), bottom, dp(18f), paint)
            val list = synchronized(history) { history.toList().takeLast(180) }
            if (list.size < 2 || baseline.isNaN()) return
            val deltas = list.map { it.m - baseline }
            val maxAbs = max(1.0, deltas.maxOf { abs(it) })
            val path = Path()
            val left = dp(28f)
            val right = w - dp(28f)
            val mid = (top + bottom) / 2f
            deltas.forEachIndexed { i, d ->
                val px = left + (right - left) * i / max(1, deltas.size - 1)
                val py = mid - (d / maxAbs).toFloat() * (bottom - top) * .32f
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            stroke.color = cyan
            stroke.strokeWidth = dp(1.2f)
            c.drawPath(path, stroke)
        }

        private fun drawMetrics(c: Canvas, w: Float, h: Float) {
            val top = dp(344f)
            val gap = dp(8f)
            val margin = dp(16f)
            val cardW = (w - margin * 2 - gap) / 2f
            val cardH = dp(72f)
            val values = arrayOf(
                Triple("X AXIS", "${fmt(x, 2)} µT", "Raw magnetic X"),
                Triple("Y AXIS", "${fmt(y, 2)} µT", "Raw magnetic Y"),
                Triple("Z AXIS", "${fmt(z, 2)} µT", "Raw magnetic Z"),
                Triple("CONFIDENCE", "${(confidence * 100).roundToInt()}%", "Periodic low-frequency"),
                Triple("SAMPLE RATE", if (sampleRate > 0) "${fmt(sampleRate, 1)} Hz" else "—", "Measured from timestamps"),
                Triple("BANDWIDTH", if (bandwidth > 0) "0–${fmt(bandwidth, 1)} Hz" else "—", "Nyquist limit"),
                Triple("OSCILLATION", if (oscillation.isNaN()) "—" else "${fmt(oscillation, 2)} Hz", "Only within bandwidth"),
                Triple("SENSOR", sensorName.take(18), accuracyLabel())
            )
            for (i in values.indices) {
                val row = i / 2
                val col = i % 2
                val l = margin + col * (cardW + gap)
                val t = top + row * (cardH + gap)
                paint.color = Color.argb(104, 0, 0, 0)
                roundRect(c, l, t, l + cardW, t + cardH, dp(17f), paint)
                stroke.color = Color.argb(30, 255, 255, 255)
                stroke.strokeWidth = 1f
                c.drawRoundRect(l, t, l + cardW, t + cardH, dp(17f), dp(17f), stroke)
                paint.color = muted
                paint.textSize = sp(8f)
                paint.typeface = Typeface.DEFAULT_BOLD
                c.drawText(values[i].first, l + dp(12f), t + dp(18f), paint)
                paint.color = white
                paint.textSize = sp(14f)
                paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
                c.drawText(values[i].second, l + dp(12f), t + dp(42f), paint)
                paint.color = Color.rgb(100, 105, 125)
                paint.textSize = sp(8f)
                paint.typeface = Typeface.DEFAULT
                c.drawText(values[i].third, l + dp(12f), t + dp(60f), paint)
            }
        }

        private fun drawBottom(c: Canvas, w: Float, h: Float) {
            val bTop = h - dp(72f)
            paint.color = Color.WHITE
            roundRect(c, dp(18f), bTop, w - dp(18f), h - dp(16f), dp(18f), paint)
            paint.color = Color.BLACK
            paint.textSize = sp(14f)
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textAlign = Paint.Align.CENTER
            c.drawText("CALIBRATE BASELINE", w / 2f, bTop + dp(35f), paint)
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.DEFAULT

            paint.color = Color.rgb(118, 124, 145)
            paint.textSize = sp(8.5f)
            paint.textAlign = Paint.Align.CENTER
            val noteY = bTop - dp(11f)
            c.drawText("Real µT sensor data • no microphone • no network • no simulated frequency", w / 2f, noteY, paint)
            paint.textAlign = Paint.Align.LEFT
        }

        private fun accuracyLabel(): String = when (sensorAccuracy) {
            SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> "Accuracy high"
            SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> "Accuracy medium"
            SensorManager.SENSOR_STATUS_ACCURACY_LOW -> "Accuracy low"
            else -> "Accuracy unreliable"
        }

        private fun fmt(v: Double, digits: Int) = "% .${digits}f".format(v).trim()
        private fun dp(v: Float) = v * resources.displayMetrics.density
        private fun sp(v: Float) = v * resources.displayMetrics.scaledDensity
        private fun roundRect(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, p: Paint) = c.drawRoundRect(l, t, r, b, rad, rad, p)
        private fun drawCentered(c: Canvas, text: String, y: Float, p: Paint) {
            p.textAlign = Paint.Align.CENTER
            c.drawText(text, width / 2f, y, p)
            p.textAlign = Paint.Align.LEFT
        }

        private fun <T> Collection<T>.takeLastCompat(n: Int): List<T> {
            if (n <= 0) return emptyList()
            val list = this.toList()
            return if (list.size <= n) list else list.subList(list.size - n, list.size)
        }
    }
}
