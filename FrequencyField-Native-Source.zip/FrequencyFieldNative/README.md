# Frequency Field Native

Standalone native Android magnetometer visualizer.

- Kotlin / Android SDK only
- No WebView
- No network permission
- No microphone
- Reads `Sensor.TYPE_MAGNETIC_FIELD` directly in microtesla (µT)
- Live X/Y/Z, total field, baseline delta, measured sample rate and Nyquist bandwidth
- Low-frequency oscillation estimator constrained by the measured sensor bandwidth
- Fluid, cymatic and particle visual modes

The app intentionally does not claim a high-frequency PEMF value that the phone sensor cannot resolve.
